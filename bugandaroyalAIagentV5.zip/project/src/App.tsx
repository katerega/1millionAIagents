import React, { useState, useEffect } from 'react';
import { Brain, GraduationCap, LineChart, PlayCircle, BookOpen, Users, ChevronRight, LogOut, Mail } from 'lucide-react';
import { LoginModal } from './components/LoginModal';
import { AITutoring } from './components/AITutoring';
import { PersonalizedLearning } from './components/PersonalizedLearning';
import { SimulationDemo } from './components/SimulationDemo';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { CollaborativeLearning } from './components/CollaborativeLearning';
import { IntelligentFeedback } from './components/IntelligentFeedback';
import { LanguageSelector } from './components/LanguageSelector';
import { AudioControls } from './components/AudioControls';
import { Communications } from './components/Communications';
import { supabase } from './lib/supabase';
import type { User } from '@supabase/supabase-js';

// Translation strings (simplified for demo)
const translations: Record<string, Record<string, string>> = {
  en: {
    welcome: "Welcome to Buganda Royal University AI Agent",
    subtitle: "Revolutionizing education through intelligent learning simulations and personalized AI tutoring",
    startDemo: "Start Demo",
    login: "Login to Start Demo",
    features: "Key Features",
  },
  es: {
    welcome: "Bienvenido al Agente de IA de la Universidad Real de Buganda",
    subtitle: "Revolucionando la educación a través de simulaciones de aprendizaje inteligente y tutoría personalizada de IA",
    startDemo: "Iniciar Demo",
    login: "Iniciar sesión para comenzar",
    features: "Características principales",
  },
  // Add more languages as needed
};

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType, title: string, description: string }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex items-center space-x-4 mb-4">
        <div className="bg-purple-100 p-3 rounded-lg">
          <Icon className="w-6 h-6 text-purple-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
      </div>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showDemo, setShowDemo] = useState(false);
  const [showTutoring, setShowTutoring] = useState(false);
  const [showPersonalized, setShowPersonalized] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showCollaboration, setShowCollaboration] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [language, setLanguage] = useState('en');
  const [lastSpokenText, setLastSpokenText] = useState('');

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleStartDemo = () => {
    if (user) {
      setShowDemo(true);
      setShowTutoring(true);
      setShowPersonalized(true);
      setShowAnalytics(true);
      setShowCollaboration(true);
      setShowFeedback(true);
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    } else {
      setShowLoginModal(true);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setShowDemo(false);
    setShowTutoring(false);
    setShowPersonalized(false);
    setShowAnalytics(false);
    setShowCollaboration(false);
    setShowFeedback(false);
  };

  const handleTranscript = (text: string) => {
    setLastSpokenText(text);
    // Handle voice commands
    const lowerText = text.toLowerCase();
    if (lowerText.includes('start demo')) {
      handleStartDemo();
    } else if (lowerText.includes('logout')) {
      handleLogout();
    }
    // Add more voice commands as needed
  };

  const t = (key: string) => translations[language]?.[key] || translations.en[key];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Controls */}
      <div className="fixed top-4 right-4 flex items-center space-x-4 z-50">
        <AudioControls
          onTranscript={handleTranscript}
          textToSpeak={lastSpokenText || t('welcome')}
        />
        <LanguageSelector
          currentLanguage={language}
          onLanguageChange={setLanguage}
        />
        {user && (
          <button
            onClick={handleLogout}
            className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors"
          >
            <span>Logout</span>
            <LogOut className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-purple-900 via-purple-800 to-purple-900 text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <div className="flex justify-center mb-6">
              <Brain className="w-16 h-16 text-purple-300" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {t('welcome')}
            </h1>
            <p className="text-xl text-purple-100 mb-8">
              {t('subtitle')}
            </p>
            <button
              onClick={handleStartDemo}
              className="bg-white text-purple-900 px-8 py-3 rounded-lg font-semibold hover:bg-purple-100 transition-colors"
            >
              {user ? t('startDemo') : t('login')}
            </button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">
          {t('features')}
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={PlayCircle}
            title="Learning Simulations"
            description="Interactive, scenario-based learning modules that simulate real-world situations"
          />
          <FeatureCard
            icon={BookOpen}
            title="AI Tutoring"
            description="Adaptive learning system that provides personalized guidance and feedback"
          />
          <FeatureCard
            icon={LineChart}
            title="Analytics Dashboard"
            description="Real-time tracking and analysis of student performance and progress"
          />
          <FeatureCard
            icon={Users}
            title="Collaborative Learning"
            description="Enable students to work together on virtual projects and simulations"
          />
          <FeatureCard
            icon={GraduationCap}
            title="Personalized Learning"
            description="Tailored content and pace based on individual student needs"
          />
          <FeatureCard
            icon={Brain}
            title="Intelligent Feedback"
            description="Immediate, constructive feedback to enhance learning outcomes"
          />
          <FeatureCard
            icon={Mail}
            title="Communications"
            description="Automated email and SMS follow-ups with bulk messaging capabilities"
          />
        </div>
      </div>

      {/* Interactive Demo Section */}
      {showDemo && (
        <div className="container mx-auto px-4 pb-16">
          <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
            Interactive Demo
          </h2>
          <p className="text-center text-gray-600 mb-8 max-w-2xl mx-auto">
            Experience how our AI agent transforms learning through interactive simulations and personalized tutoring.
          </p>
          <SimulationDemo />
        </div>
      )}

      {/* Analytics Dashboard Section */}
      {showAnalytics && <AnalyticsDashboard />}

      {/* Collaborative Learning Section */}
      {showCollaboration && <CollaborativeLearning />}

      {/* Personalized Learning Section */}
      {showPersonalized && <PersonalizedLearning />}

      {/* Intelligent Feedback Section */}
      {showFeedback && <IntelligentFeedback />}

      {/* AI Tutoring Section */}
      {showTutoring && <AITutoring />}

      {/* Communications Section */}
      {user && (
        <div className="container mx-auto px-4 pb-16">
          <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
            Communications Center
          </h2>
          <Communications />
        </div>
      )}

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSuccess={() => {
          setShowLoginModal(false);
          setShowDemo(true);
          setShowTutoring(true);
          setShowPersonalized(true);
          setShowAnalytics(true);
          setShowCollaboration(true);
          setShowFeedback(true);
          window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        }}
      />
    </div>
  );
}

export default App;