import React, { useState, useEffect } from 'react';
import { Brain, ThumbsUp, ThumbsDown, ArrowRight, RefreshCcw } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
  difficulty: number;
  explanation: string;
  topic: string;
}

const sampleQuestions: Question[] = [
  {
    id: 1,
    text: "What is the primary function of mitochondria in a cell?",
    options: [
      "Energy production",
      "Protein synthesis",
      "Cell division",
      "Waste removal"
    ],
    correctAnswer: 0,
    difficulty: 1,
    explanation: "Mitochondria are often called the powerhouse of the cell because they produce energy through cellular respiration.",
    topic: "Cell Biology"
  },
  {
    id: 2,
    text: "Which of the following is a characteristic of enzymes?",
    options: [
      "They are consumed in reactions",
      "They increase activation energy",
      "They are catalysts",
      "They only work at high temperatures"
    ],
    correctAnswer: 2,
    difficulty: 2,
    explanation: "Enzymes are biological catalysts that speed up chemical reactions without being consumed in the process.",
    topic: "Biochemistry"
  },
  {
    id: 3,
    text: "What is the role of DNA polymerase in DNA replication?",
    options: [
      "It unwinds the DNA helix",
      "It synthesizes new DNA strands",
      "It joins DNA fragments",
      "It proofreads RNA"
    ],
    correctAnswer: 1,
    difficulty: 3,
    explanation: "DNA polymerase is responsible for synthesizing new DNA strands during DNA replication by adding nucleotides complementary to the template strand.",
    topic: "Molecular Biology"
  }
];

export function AITutoring() {
  const [currentQuestion, setCurrentQuestion] = useState<Question>(sampleQuestions[0]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [userLevel, setUserLevel] = useState(1);
  const [streak, setStreak] = useState(0);

  const handleAnswerSelect = (index: number) => {
    setSelectedAnswer(index);
    const correct = index === currentQuestion.correctAnswer;
    setIsCorrect(correct);
    setShowExplanation(true);

    // Update user level based on performance
    if (correct) {
      setStreak(prev => prev + 1);
      if (streak >= 2) {
        setUserLevel(prev => Math.min(prev + 1, 3));
        setStreak(0);
      }
    } else {
      setStreak(0);
      if (userLevel > 1) {
        setUserLevel(prev => prev - 1);
      }
    }
  };

  const getNextQuestion = () => {
    // Filter questions by current user level
    const levelQuestions = sampleQuestions.filter(q => q.difficulty === userLevel);
    const nextQuestion = levelQuestions[Math.floor(Math.random() * levelQuestions.length)];
    setCurrentQuestion(nextQuestion || sampleQuestions[0]);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setShowExplanation(false);
  };

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Brain className="w-6 h-6 text-purple-600" />
          <h2 className="text-2xl font-bold text-gray-800">AI Tutor</h2>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-600">Difficulty Level: {userLevel}</span>
          <span className="text-sm text-gray-600">Streak: {streak}</span>
        </div>
      </div>

      <div className="mb-8">
        <div className="text-lg font-medium text-gray-800 mb-4">
          {currentQuestion.text}
        </div>
        <div className="space-y-3">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(index)}
              disabled={selectedAnswer !== null}
              className={`w-full p-4 text-left rounded-lg transition-colors ${
                selectedAnswer === null
                  ? 'hover:bg-purple-50 bg-gray-50'
                  : selectedAnswer === index
                  ? isCorrect
                    ? 'bg-green-100 border-green-500'
                    : 'bg-red-100 border-red-500'
                  : index === currentQuestion.correctAnswer && showExplanation
                  ? 'bg-green-100 border-green-500'
                  : 'bg-gray-50'
              } ${
                selectedAnswer === null ? 'border border-gray-200' : 'border-2'
              }`}
            >
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {selectedAnswer === index && (
                  isCorrect ? (
                    <ThumbsUp className="w-5 h-5 text-green-600" />
                  ) : (
                    <ThumbsDown className="w-5 h-5 text-red-600" />
                  )
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {showExplanation && (
        <div className={`p-4 rounded-lg mb-6 ${
          isCorrect ? 'bg-green-50' : 'bg-red-50'
        }`}>
          <h3 className="font-semibold mb-2">
            {isCorrect ? 'Excellent!' : 'Let\'s Learn From This'}
          </h3>
          <p className="text-gray-700">{currentQuestion.explanation}</p>
        </div>
      )}

      {selectedAnswer !== null && (
        <div className="flex justify-end">
          <button
            onClick={getNextQuestion}
            className="flex items-center space-x-2 bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <span>Next Question</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}