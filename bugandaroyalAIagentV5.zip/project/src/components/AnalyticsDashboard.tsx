import React, { useState } from 'react';
import { BarChart as BarChartIcon, PieChart, LineChart, Activity, Clock, Brain, Target, Award, ArrowUp, ArrowDown } from 'lucide-react';

interface PerformanceMetric {
  subject: string;
  score: number;
  improvement: number;
  timeSpent: string;
}

interface SkillProgress {
  skill: string;
  level: number;
  progress: number;
}

interface LearningPattern {
  day: string;
  hoursSpent: number;
  activitiesCompleted: number;
}

const performanceData: PerformanceMetric[] = [
  { subject: 'Cell Biology', score: 85, improvement: 12, timeSpent: '24h' },
  { subject: 'Genetics', score: 78, improvement: 8, timeSpent: '18h' },
  { subject: 'Molecular Biology', score: 92, improvement: 15, timeSpent: '30h' },
  { subject: 'Biochemistry', score: 88, improvement: 10, timeSpent: '22h' },
];

const skillsProgress: SkillProgress[] = [
  { skill: 'Critical Thinking', level: 4, progress: 75 },
  { skill: 'Problem Solving', level: 3, progress: 60 },
  { skill: 'Lab Techniques', level: 5, progress: 90 },
  { skill: 'Data Analysis', level: 4, progress: 85 },
];

const learningPatterns: LearningPattern[] = [
  { day: 'Mon', hoursSpent: 3, activitiesCompleted: 5 },
  { day: 'Tue', hoursSpent: 4, activitiesCompleted: 6 },
  { day: 'Wed', hoursSpent: 2, activitiesCompleted: 3 },
  { day: 'Thu', hoursSpent: 5, activitiesCompleted: 7 },
  { day: 'Fri', hoursSpent: 3, activitiesCompleted: 4 },
];

export function AnalyticsDashboard() {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'week' | 'month' | 'year'>('week');
  const [selectedMetric, setSelectedMetric] = useState<'performance' | 'skills' | 'patterns'>('performance');

  const averageScore = performanceData.reduce((acc, curr) => acc + curr.score, 0) / performanceData.length;
  const totalTimeSpent = performanceData.reduce((acc, curr) => acc + parseInt(curr.timeSpent), 0);
  const averageImprovement = performanceData.reduce((acc, curr) => acc + curr.improvement, 0) / performanceData.length;

  const MetricCard = ({ title, value, icon: Icon, trend }: { title: string; value: string; icon: React.ElementType; trend?: number }) => (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-600 font-medium">{title}</h3>
        <Icon className="w-5 h-5 text-purple-600" />
      </div>
      <div className="flex items-end justify-between">
        <p className="text-2xl font-bold text-gray-800">{value}</p>
        {trend && (
          <div className={`flex items-center ${trend > 0 ? 'text-green-500' : 'text-red-500'}`}>
            {trend > 0 ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
            <span className="ml-1">{Math.abs(trend)}%</span>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Performance Analytics</h2>
        <div className="flex space-x-2">
          {(['week', 'month', 'year'] as const).map((timeframe) => (
            <button
              key={timeframe}
              onClick={() => setSelectedTimeframe(timeframe)}
              className={`px-4 py-2 rounded-lg transition-colors ${
                selectedTimeframe === timeframe
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {timeframe.charAt(0).toUpperCase() + timeframe.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Overview Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Average Score"
          value={`${averageScore.toFixed(1)}%`}
          icon={Award}
          trend={8}
        />
        <MetricCard
          title="Total Study Time"
          value={`${totalTimeSpent}h`}
          icon={Clock}
        />
        <MetricCard
          title="Improvement Rate"
          value={`${averageImprovement.toFixed(1)}%`}
          icon={Activity}
          trend={averageImprovement}
        />
      </div>

      {/* Detailed Analytics */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="border-b border-gray-200">
          <div className="flex">
            {(['performance', 'skills', 'patterns'] as const).map((metric) => (
              <button
                key={metric}
                onClick={() => setSelectedMetric(metric)}
                className={`px-6 py-4 font-medium transition-colors ${
                  selectedMetric === metric
                    ? 'border-b-2 border-purple-600 text-purple-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {metric.charAt(0).toUpperCase() + metric.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6">
          {selectedMetric === 'performance' && (
            <div className="space-y-6">
              {performanceData.map((subject) => (
                <div key={subject.subject} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">{subject.subject}</span>
                    <span className="text-sm text-gray-500">{subject.score}%</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-purple-600 rounded-full"
                      style={{ width: `${subject.score}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {selectedMetric === 'skills' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {skillsProgress.map((skill) => (
                <div key={skill.skill} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-gray-700">{skill.skill}</span>
                    <span className="text-sm text-purple-600">Level {skill.level}</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-purple-600 rounded-full"
                      style={{ width: `${skill.progress}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {selectedMetric === 'patterns' && (
            <div className="space-y-6">
              <div className="flex justify-between items-end h-40">
                {learningPatterns.map((pattern) => (
                  <div key={pattern.day} className="flex flex-col items-center space-y-2">
                    <div
                      className="w-12 bg-purple-600 rounded-t"
                      style={{ height: `${pattern.hoursSpent * 20}px` }}
                    />
                    <span className="text-sm text-gray-600">{pattern.day}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-sm text-gray-500">
                <span>Average Time: 3.4h/day</span>
                <span>Peak Performance: Thursday</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}