import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, VolumeX } from 'lucide-react';
import 'regenerator-runtime/runtime';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

interface AudioControlsProps {
  onTranscript: (text: string) => void;
  textToSpeak?: string;
}

export function AudioControls({ onTranscript, textToSpeak }: AudioControlsProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  useEffect(() => {
    if (transcript) {
      onTranscript(transcript);
    }
  }, [transcript, onTranscript]);

  const handleSpeak = () => {
    if (!textToSpeak) return;

    setIsSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.onend = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const handleStopSpeaking = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  if (!browserSupportsSpeechRecognition) {
    return null;
  }

  return (
    <div className="flex items-center space-x-4">
      <button
        onClick={listening ? SpeechRecognition.stopListening : SpeechRecognition.startListening}
        className={`p-2 rounded-lg transition-colors ${
          listening
            ? 'bg-red-100 text-red-600 hover:bg-red-200'
            : 'bg-purple-100 text-purple-600 hover:bg-purple-200'
        }`}
        title={listening ? 'Stop listening' : 'Start listening'}
      >
        {listening ? (
          <MicOff className="w-5 h-5" />
        ) : (
          <Mic className="w-5 h-5" />
        )}
      </button>

      {textToSpeak && (
        <button
          onClick={isSpeaking ? handleStopSpeaking : handleSpeak}
          className={`p-2 rounded-lg transition-colors ${
            isSpeaking
              ? 'bg-red-100 text-red-600 hover:bg-red-200'
              : 'bg-purple-100 text-purple-600 hover:bg-purple-200'
          }`}
          title={isSpeaking ? 'Stop speaking' : 'Start speaking'}
        >
          {isSpeaking ? (
            <VolumeX className="w-5 h-5" />
          ) : (
            <Volume2 className="w-5 h-5" />
          )}
        </button>
      )}
    </div>
  );
}