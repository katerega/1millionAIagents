import React, { useState } from 'react';
import { Users, MessageSquare, FileText, Share2, UserPlus, Clock, Target, CheckCircle2, AlertCircle } from 'lucide-react';

interface Project {
  id: number;
  title: string;
  description: string;
  deadline: string;
  progress: number;
  team: TeamMember[];
  tasks: Task[];
  status: 'active' | 'completed' | 'pending';
}

interface TeamMember {
  id: number;
  name: string;
  role: string;
  avatar: string;
  status: 'online' | 'offline' | 'busy';
}

interface Task {
  id: number;
  title: string;
  assignee: number;
  status: 'todo' | 'in-progress' | 'completed';
  priority: 'low' | 'medium' | 'high';
}

const projects: Project[] = [
  {
    id: 1,
    title: "Genetic Engineering Simulation",
    description: "Collaborate on CRISPR gene editing simulation and analyze results",
    deadline: "2024-04-15",
    progress: 65,
    status: 'active',
    team: [
      {
        id: 1,
        name: "Sarah Chen",
        role: "Team Lead",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100",
        status: 'online'
      },
      {
        id: 2,
        name: "Michael Park",
        role: "Research Assistant",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100",
        status: 'busy'
      },
      {
        id: 3,
        name: "Emma Wilson",
        role: "Data Analyst",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=100",
        status: 'offline'
      }
    ],
    tasks: [
      {
        id: 1,
        title: "Design experimental protocol",
        assignee: 1,
        status: 'completed',
        priority: 'high'
      },
      {
        id: 2,
        title: "Run simulation trials",
        assignee: 2,
        status: 'in-progress',
        priority: 'high'
      },
      {
        id: 3,
        title: "Analyze preliminary results",
        assignee: 3,
        status: 'todo',
        priority: 'medium'
      }
    ]
  },
  {
    id: 2,
    title: "Cell Signaling Pathways",
    description: "Map and analyze cellular communication networks",
    deadline: "2024-04-30",
    progress: 35,
    status: 'active',
    team: [
      {
        id: 4,
        name: "David Kim",
        role: "Project Manager",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100",
        status: 'online'
      },
      {
        id: 5,
        name: "Lisa Johnson",
        role: "Researcher",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100",
        status: 'online'
      }
    ],
    tasks: [
      {
        id: 4,
        title: "Literature review",
        assignee: 4,
        status: 'completed',
        priority: 'medium'
      },
      {
        id: 5,
        title: "Pathway modeling",
        assignee: 5,
        status: 'in-progress',
        priority: 'high'
      }
    ]
  }
];

export function CollaborativeLearning() {
  const [selectedProject, setSelectedProject] = useState<Project>(projects[0]);
  const [activeTab, setActiveTab] = useState<'overview' | 'tasks' | 'team'>('overview');

  const getStatusColor = (status: Project['status'] | Task['status']) => {
    switch (status) {
      case 'active':
      case 'in-progress':
        return 'bg-blue-100 text-blue-700';
      case 'completed':
        return 'bg-green-100 text-green-700';
      case 'pending':
      case 'todo':
        return 'bg-yellow-100 text-yellow-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'high':
        return 'text-red-500';
      case 'medium':
        return 'text-yellow-500';
      case 'low':
        return 'text-green-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className="max-w-6xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
      {/* Project Header */}
      <div className="p-6 bg-purple-900 text-white">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-2xl font-bold">{selectedProject.title}</h2>
            <p className="text-purple-200 mt-1">{selectedProject.description}</p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 hover:bg-purple-800 rounded-lg transition-colors">
              <Share2 className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-purple-800 rounded-lg transition-colors">
              <UserPlus className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="mt-6 flex items-center space-x-4">
          <div className="flex -space-x-2">
            {selectedProject.team.map(member => (
              <img
                key={member.id}
                src={member.avatar}
                alt={member.name}
                className="w-8 h-8 rounded-full border-2 border-purple-900"
                title={`${member.name} - ${member.role}`}
              />
            ))}
          </div>
          <span className="text-purple-200">
            {selectedProject.team.length} team members
          </span>
          <div className="ml-auto flex items-center space-x-2">
            <Clock className="w-4 h-4 text-purple-200" />
            <span className="text-purple-200">
              Deadline: {selectedProject.deadline}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex">
          {(['overview', 'tasks', 'team'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-4 font-medium transition-colors ${
                activeTab === tab
                  ? 'border-b-2 border-purple-600 text-purple-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Progress Overview */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">Project Progress</h3>
              <div className="relative pt-1">
                <div className="flex mb-2 items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-purple-600 bg-purple-200">
                      {selectedProject.progress}% Complete
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-semibold inline-block text-purple-600">
                      {selectedProject.tasks.filter(t => t.status === 'completed').length}/
                      {selectedProject.tasks.length} Tasks
                    </span>
                  </div>
                </div>
                <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-purple-200">
                  <div
                    style={{ width: `${selectedProject.progress}%` }}
                    className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-purple-600"
                  />
                </div>
              </div>
            </div>

            {/* Project Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {projects.map(project => (
                <button
                  key={project.id}
                  onClick={() => setSelectedProject(project)}
                  className={`p-4 rounded-lg border-2 transition-colors ${
                    selectedProject.id === project.id
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-200 hover:border-purple-300'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold">{project.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{project.description}</p>
                      <div className="mt-2 flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
                          {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                        </span>
                        <span className="text-sm text-gray-500">
                          {project.team.length} members
                        </span>
                      </div>
                    </div>
                    <Target className="w-5 h-5 text-purple-600" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'tasks' && (
          <div className="space-y-4">
            {selectedProject.tasks.map(task => (
              <div
                key={task.id}
                className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`mt-1 w-4 h-4 rounded-full ${
                      task.status === 'completed' ? 'bg-green-500' : 'bg-gray-200'
                    }`} />
                    <div>
                      <h4 className="font-medium">{task.title}</h4>
                      <div className="mt-1 flex items-center space-x-2 text-sm">
                        <span className={`font-medium ${getPriorityColor(task.priority)}`}>
                          {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
                        </span>
                        <span className="text-gray-400">•</span>
                        <span className={`px-2 py-0.5 rounded-full text-xs ${getStatusColor(task.status)}`}>
                          {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <img
                    src={selectedProject.team.find(m => m.id === task.assignee)?.avatar}
                    alt="Assignee"
                    className="w-8 h-8 rounded-full"
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'team' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {selectedProject.team.map(member => (
              <div
                key={member.id}
                className="p-4 border border-gray-200 rounded-lg flex items-center space-x-4"
              >
                <div className="relative">
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="w-12 h-12 rounded-full"
                  />
                  <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                    member.status === 'online' ? 'bg-green-500' :
                    member.status === 'busy' ? 'bg-red-500' : 'bg-gray-500'
                  }`} />
                </div>
                <div>
                  <h4 className="font-medium">{member.name}</h4>
                  <p className="text-sm text-gray-600">{member.role}</p>
                  <span className={`text-xs ${
                    member.status === 'online' ? 'text-green-600' :
                    member.status === 'busy' ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}