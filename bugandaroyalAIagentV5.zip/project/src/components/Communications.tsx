import React, { useState, useEffect } from 'react';
import { Mail, MessageSquare, Calendar, Clock, Plus, Trash2, Edit, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Template {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: 'email' | 'sms';
  variables: string[];
}

interface ScheduledMessage {
  id: string;
  template_id: string;
  recipients: string[];
  scheduled_for: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
}

export function Communications() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [scheduledMessages, setScheduledMessages] = useState<ScheduledMessage[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    subject: '',
    content: '',
    type: 'email' as const,
    variables: [] as string[]
  });
  const [recipients, setRecipients] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [showTemplateForm, setShowTemplateForm] = useState(false);

  useEffect(() => {
    loadTemplates();
    loadScheduledMessages();
  }, []);

  const loadTemplates = async () => {
    const { data, error } = await supabase
      .from('message_templates')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading templates:', error);
      return;
    }

    setTemplates(data);
  };

  const loadScheduledMessages = async () => {
    const { data, error } = await supabase
      .from('scheduled_messages')
      .select('*')
      .order('scheduled_for', { ascending: true });

    if (error) {
      console.error('Error loading scheduled messages:', error);
      return;
    }

    setScheduledMessages(data);
  };

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();

    const { error } = await supabase
      .from('message_templates')
      .insert([{
        ...newTemplate,
        variables: newTemplate.variables.length ? newTemplate.variables : null
      }]);

    if (error) {
      console.error('Error creating template:', error);
      return;
    }

    setNewTemplate({
      name: '',
      subject: '',
      content: '',
      type: 'email',
      variables: []
    });
    setShowTemplateForm(false);
    loadTemplates();
  };

  const handleScheduleMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTemplate) return;

    const recipientList = recipients.split('\n').map(r => r.trim()).filter(Boolean);

    const { error } = await supabase
      .from('scheduled_messages')
      .insert([{
        template_id: selectedTemplate.id,
        recipients: recipientList,
        scheduled_for: new Date(scheduledDate).toISOString()
      }]);

    if (error) {
      console.error('Error scheduling message:', error);
      return;
    }

    setRecipients('');
    setScheduledDate('');
    setSelectedTemplate(null);
    loadScheduledMessages();
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Communications Center</h2>
        <button
          onClick={() => setShowTemplateForm(true)}
          className="flex items-center space-x-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Template</span>
        </button>
      </div>

      {/* Template Form */}
      {showTemplateForm && (
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Create Message Template</h3>
          <form onSubmit={handleCreateTemplate} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Template Name</label>
              <input
                type="text"
                value={newTemplate.name}
                onChange={e => setNewTemplate(prev => ({ ...prev, name: e.target.value }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Type</label>
              <select
                value={newTemplate.type}
                onChange={e => setNewTemplate(prev => ({ ...prev, type: e.target.value as 'email' | 'sms' }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
              >
                <option value="email">Email</option>
                <option value="sms">SMS</option>
              </select>
            </div>

            {newTemplate.type === 'email' && (
              <div>
                <label className="block text-sm font-medium text-gray-700">Subject</label>
                <input
                  type="text"
                  value={newTemplate.subject}
                  onChange={e => setNewTemplate(prev => ({ ...prev, subject: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">Content</label>
              <textarea
                value={newTemplate.content}
                onChange={e => setNewTemplate(prev => ({ ...prev, content: e.target.value }))}
                rows={6}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                required
              />
            </div>

            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setShowTemplateForm(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
              >
                Create Template
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Templates List */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Message Templates</h3>
          <div className="space-y-4">
            {templates.map(template => (
              <div
                key={template.id}
                className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-medium">{template.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      Type: {template.type.toUpperCase()}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setSelectedTemplate(template)}
                      className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Schedule Message Form */}
        {selectedTemplate && (
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold mb-4">Schedule Message</h3>
            <form onSubmit={handleScheduleMessage} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Using Template</label>
                <div className="mt-1 p-3 bg-purple-50 rounded-lg">
                  <p className="font-medium">{selectedTemplate.name}</p>
                  <p className="text-sm text-gray-600">{selectedTemplate.type.toUpperCase()}</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Recipients (one per line)</label>
                <textarea
                  value={recipients}
                  onChange={e => setRecipients(e.target.value)}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  placeholder={selectedTemplate.type === 'email' ? 'email@example.com' : '+1234567890'}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Schedule For</label>
                <input
                  type="datetime-local"
                  value={scheduledDate}
                  onChange={e => setScheduledDate(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  required
                />
              </div>

              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setSelectedTemplate(null)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
                >
                  Schedule
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Scheduled Messages */}
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h3 className="text-lg font-semibold mb-4">Scheduled Messages</h3>
        <div className="space-y-4">
          {scheduledMessages.map(message => (
            <div
              key={message.id}
              className="p-4 border border-gray-200 rounded-lg"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-purple-600" />
                    <span className="font-medium">
                      {new Date(message.scheduled_for).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    Recipients: {message.recipients.length}
                  </p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  message.status === 'completed' ? 'bg-green-100 text-green-800' :
                  message.status === 'failed' ? 'bg-red-100 text-red-800' :
                  message.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {message.status.replace('_', ' ').toUpperCase()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}