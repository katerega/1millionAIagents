import React, { useState } from 'react';
import { Brain, MessageSquare, Target, CheckCircle, AlertTriangle, ArrowRight, Lightbulb, Award } from 'lucide-react';

interface FeedbackScenario {
  id: number;
  title: string;
  description: string;
  type: 'exam' | 'interview' | 'skill';
  questions: Question[];
}

interface Question {
  id: number;
  text: string;
  options?: string[];
  correctAnswer?: number;
  sampleAnswer?: string;
  rubric?: {
    excellent: string;
    good: string;
    needsImprovement: string;
  };
  feedbackPoints: string[];
  skillLevel?: 'beginner' | 'intermediate' | 'advanced';
}

const scenarios: FeedbackScenario[] = [
  {
    id: 1,
    title: "Technical Interview Practice",
    description: "Practice common software engineering interview questions",
    type: "interview",
    questions: [
      {
        id: 1,
        text: "Can you explain how you would design a scalable web application?",
        sampleAnswer: "I would start by identifying the key requirements and constraints. Then, I'd design the system architecture considering scalability, reliability, and maintainability. This includes choosing appropriate technologies, designing the database schema, and planning for future growth.",
        rubric: {
          excellent: "Comprehensive answer covering architecture, scalability, and specific technologies",
          good: "Good overview but missing some technical details",
          needsImprovement: "Basic answer lacking technical depth"
        },
        feedbackPoints: [
          "Consider mentioning specific technologies and their trade-offs",
          "Include examples of scaling strategies (horizontal vs vertical)",
          "Discuss monitoring and maintenance approaches"
        ]
      },
      {
        id: 2,
        text: "How do you handle conflicts in a team environment?",
        sampleAnswer: "I believe in addressing conflicts directly but professionally. I focus on understanding different perspectives, finding common ground, and working towards solutions that benefit the team and project.",
        rubric: {
          excellent: "Shows maturity, empathy, and problem-solving skills",
          good: "Demonstrates understanding of conflict resolution",
          needsImprovement: "Too general or avoids addressing conflict"
        },
        feedbackPoints: [
          "Include specific examples from past experiences",
          "Emphasize communication and listening skills",
          "Discuss follow-up and relationship building"
        ]
      }
    ]
  },
  {
    id: 2,
    title: "Biology Final Exam Prep",
    description: "Practice questions for advanced biology concepts",
    type: "exam",
    questions: [
      {
        id: 3,
        text: "Explain the process of cellular respiration and its importance.",
        options: [
          "It's how cells produce energy through glucose breakdown",
          "It's the process of cell division",
          "It's how cells communicate",
          "It's the process of protein synthesis"
        ],
        correctAnswer: 0,
        feedbackPoints: [
          "Remember to mention ATP production",
          "Connect to real-world energy needs",
          "Explain the relationship with photosynthesis"
        ]
      },
      {
        id: 4,
        text: "Describe the structure and function of DNA.",
        options: [
          "Single helix storing protein information",
          "Double helix storing genetic information",
          "Triple helix storing cell information",
          "Circular structure storing RNA"
        ],
        correctAnswer: 1,
        feedbackPoints: [
          "Include base pair relationships",
          "Mention role in protein synthesis",
          "Discuss DNA replication"
        ]
      }
    ]
  },
  {
    id: 3,
    title: "Research Skills Assessment",
    description: "Evaluate and improve research methodology skills",
    type: "skill",
    questions: [
      {
        id: 5,
        text: "Design an experiment to test the effects of temperature on enzyme activity.",
        skillLevel: "intermediate",
        rubric: {
          excellent: "Comprehensive experimental design with controls and variables",
          good: "Basic design with some methodology gaps",
          needsImprovement: "Incomplete design lacking key elements"
        },
        feedbackPoints: [
          "Consider all variables that need to be controlled",
          "Include appropriate data collection methods",
          "Plan for statistical analysis"
        ]
      }
    ]
  }
];

export function IntelligentFeedback() {
  const [selectedScenario, setSelectedScenario] = useState<FeedbackScenario | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState<string[]>([]);
  const [showFeedback, setShowFeedback] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  const currentQuestion = selectedScenario?.questions[currentQuestionIndex];

  const handleScenarioSelect = (scenario: FeedbackScenario) => {
    setSelectedScenario(scenario);
    setCurrentQuestionIndex(0);
    setAnswer('');
    setFeedback([]);
    setShowFeedback(false);
    setSelectedOption(null);
  };

  const handleSubmit = () => {
    if (!currentQuestion) return;

    let newFeedback: string[] = [];

    if (currentQuestion.options && selectedOption !== null) {
      if (selectedOption === currentQuestion.correctAnswer) {
        newFeedback = ['Correct! Well done!', ...currentQuestion.feedbackPoints];
      } else {
        newFeedback = ['Incorrect. Let\'s review the concept:', ...currentQuestion.feedbackPoints];
      }
    } else if (answer) {
      // Analyze text answer
      const wordCount = answer.split(' ').length;
      const keywordMatches = currentQuestion.feedbackPoints.filter(point =>
        answer.toLowerCase().includes(point.toLowerCase())
      );

      if (wordCount < 50) {
        newFeedback.push('Consider providing more detail in your answer.');
      }
      if (keywordMatches.length < currentQuestion.feedbackPoints.length) {
        newFeedback.push('You might want to address these additional points:');
        newFeedback.push(...currentQuestion.feedbackPoints.filter(point =>
          !keywordMatches.includes(point)
        ));
      }
      if (currentQuestion.rubric) {
        if (wordCount > 100 && keywordMatches.length > currentQuestion.feedbackPoints.length / 2) {
          newFeedback.unshift(currentQuestion.rubric.excellent);
        } else if (wordCount > 50) {
          newFeedback.unshift(currentQuestion.rubric.good);
        } else {
          newFeedback.unshift(currentQuestion.rubric.needsImprovement);
        }
      }
    }

    setFeedback(newFeedback);
    setShowFeedback(true);
  };

  const handleNext = () => {
    if (currentQuestionIndex < (selectedScenario?.questions.length || 0) - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setAnswer('');
      setFeedback([]);
      setShowFeedback(false);
      setSelectedOption(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      {!selectedScenario ? (
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-800">Select Practice Scenario</h2>
            <Brain className="w-8 h-8 text-purple-600" />
          </div>

          <div className="grid gap-4">
            {scenarios.map(scenario => (
              <button
                key={scenario.id}
                onClick={() => handleScenarioSelect(scenario)}
                className="p-6 rounded-xl border-2 border-gray-200 hover:border-purple-300 transition-all"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">{scenario.title}</h3>
                    <p className="text-gray-600">{scenario.description}</p>
                  </div>
                  {scenario.type === 'exam' ? (
                    <Award className="w-6 h-6 text-purple-600" />
                  ) : scenario.type === 'interview' ? (
                    <MessageSquare className="w-6 h-6 text-purple-600" />
                  ) : (
                    <Target className="w-6 h-6 text-purple-600" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">{selectedScenario.title}</h2>
              <p className="text-gray-600 mt-1">{selectedScenario.description}</p>
            </div>
            <button
              onClick={() => setSelectedScenario(null)}
              className="text-purple-600 hover:text-purple-700"
            >
              Change Scenario
            </button>
          </div>

          {currentQuestion && (
            <div className="space-y-6">
              <div className="p-6 bg-purple-50 rounded-xl">
                <h3 className="text-lg font-semibold mb-4">{currentQuestion.text}</h3>
                
                {currentQuestion.options ? (
                  <div className="space-y-3">
                    {currentQuestion.options.map((option, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedOption(index)}
                        className={`w-full p-4 text-left rounded-lg transition-colors ${
                          selectedOption === index
                            ? 'bg-purple-100 border-2 border-purple-600'
                            : 'bg-white border-2 border-gray-200 hover:border-purple-300'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                ) : (
                  <textarea
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                    placeholder="Type your answer here..."
                    className="w-full h-32 p-4 rounded-lg border-2 border-gray-200 focus:border-purple-300 focus:ring-2 focus:ring-purple-100"
                  />
                )}
              </div>

              {!showFeedback ? (
                <button
                  onClick={handleSubmit}
                  className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2"
                >
                  <span>Submit Answer</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <div className="space-y-4">
                  <div className="p-6 bg-green-50 rounded-xl">
                    <div className="flex items-start space-x-3">
                      <div className="mt-1">
                        {feedback[0]?.includes('Correct') ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : feedback[0]?.includes('Incorrect') ? (
                          <AlertTriangle className="w-5 h-5 text-yellow-600" />
                        ) : (
                          <Lightbulb className="w-5 h-5 text-purple-600" />
                        )}
                      </div>
                      <div className="space-y-3">
                        {feedback.map((point, index) => (
                          <p key={index} className="text-gray-700">{point}</p>
                        ))}
                      </div>
                    </div>
                  </div>

                  {currentQuestionIndex < selectedScenario.questions.length - 1 && (
                    <button
                      onClick={handleNext}
                      className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2"
                    >
                      <span>Next Question</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}