import React, { useState, useEffect } from 'react';
import { Book, Brain, Target, Clock, ArrowRight, CheckCircle, BarChart } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface LearningPath {
  id: number;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: string;
  topics: string[];
  prerequisites: string[];
}

interface LearningProgress {
  completedTopics: string[];
  currentLevel: string;
  preferredPace: 'slow' | 'medium' | 'fast';
  strengths: string[];
  areasForImprovement: string[];
}

const learningPaths: LearningPath[] = [
  {
    id: 1,
    title: "Foundations of Biology",
    description: "Essential concepts in biological sciences",
    difficulty: "beginner",
    estimatedTime: "4-6 weeks",
    topics: ["Cell Biology", "Basic Genetics", "Human Anatomy"],
    prerequisites: []
  },
  {
    id: 2,
    title: "Advanced Molecular Biology",
    description: "Deep dive into molecular mechanisms",
    difficulty: "intermediate",
    estimatedTime: "6-8 weeks",
    topics: ["DNA Replication", "Protein Synthesis", "Gene Regulation"],
    prerequisites: ["Cell Biology", "Basic Genetics"]
  },
  {
    id: 3,
    title: "Specialized Research Methods",
    description: "Advanced research techniques and methodologies",
    difficulty: "advanced",
    estimatedTime: "8-10 weeks",
    topics: ["Lab Techniques", "Data Analysis", "Research Design"],
    prerequisites: ["Advanced Molecular Biology"]
  }
];

export function PersonalizedLearning() {
  const [selectedPath, setSelectedPath] = useState<LearningPath | null>(null);
  const [progress, setProgress] = useState<LearningProgress>({
    completedTopics: [],
    currentLevel: 'beginner',
    preferredPace: 'medium',
    strengths: [],
    areasForImprovement: []
  });
  const [showAssessment, setShowAssessment] = useState(true);

  const handlePathSelect = (path: LearningPath) => {
    setSelectedPath(path);
    setShowAssessment(false);
  };

  const handlePaceChange = (pace: 'slow' | 'medium' | 'fast') => {
    setProgress(prev => ({ ...prev, preferredPace: pace }));
  };

  const getRecommendedPath = () => {
    return learningPaths.find(path => path.difficulty === progress.currentLevel) || learningPaths[0];
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      {showAssessment ? (
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-800">Learning Style Assessment</h2>
            <Brain className="w-8 h-8 text-purple-600" />
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Preferred Learning Pace</h3>
              <div className="flex space-x-4">
                {(['slow', 'medium', 'fast'] as const).map(pace => (
                  <button
                    key={pace}
                    onClick={() => handlePaceChange(pace)}
                    className={`px-6 py-3 rounded-lg border-2 transition-colors ${
                      progress.preferredPace === pace
                        ? 'border-purple-600 bg-purple-50 text-purple-700'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4" />
                      <span className="capitalize">{pace}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setShowAssessment(false)}
              className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2"
            >
              <span>View Personalized Recommendations</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-800">Your Learning Journey</h2>
            <Target className="w-8 h-8 text-purple-600" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-purple-50 rounded-xl">
              <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
                <BarChart className="w-5 h-5 text-purple-600" />
                <span>Your Progress</span>
              </h3>
              <div className="space-y-3">
                <p className="text-gray-600">Current Level: {progress.currentLevel}</p>
                <p className="text-gray-600">Preferred Pace: {progress.preferredPace}</p>
                <p className="text-gray-600">
                  Completed Topics: {progress.completedTopics.length}
                </p>
              </div>
            </div>

            <div className="p-6 bg-green-50 rounded-xl">
              <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span>Recommended Next Steps</span>
              </h3>
              <div className="space-y-3">
                <p className="text-gray-600">
                  Recommended Path: {getRecommendedPath().title}
                </p>
                <p className="text-gray-600">
                  Estimated Time: {getRecommendedPath().estimatedTime}
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Available Learning Paths</h3>
            <div className="grid gap-4">
              {learningPaths.map(path => (
                <button
                  key={path.id}
                  onClick={() => handlePathSelect(path)}
                  className={`p-6 rounded-xl border-2 transition-all ${
                    selectedPath?.id === path.id
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-200 hover:border-purple-300'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-lg font-semibold mb-2">{path.title}</h4>
                      <p className="text-gray-600 mb-4">{path.description}</p>
                      <div className="flex items-center space-x-4 text-sm">
                        <span className="text-purple-600">
                          {path.estimatedTime}
                        </span>
                        <span className="text-gray-500 capitalize">
                          {path.difficulty}
                        </span>
                      </div>
                    </div>
                    <Book className="w-6 h-6 text-purple-600" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}