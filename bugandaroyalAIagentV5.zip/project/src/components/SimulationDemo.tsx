import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, ChevronRight, ChevronLeft, Beaker, Microscope, FlaskRound as Flask } from 'lucide-react';

interface Simulation {
  id: number;
  title: string;
  description: string;
  steps: SimulationStep[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  category: string;
}

interface SimulationStep {
  id: number;
  title: string;
  description: string;
  action: string;
  feedback: string;
  image: string;
}

const simulations: Simulation[] = [
  {
    id: 1,
    title: "Cell Division Mitosis",
    description: "Observe and control the stages of cell division in real-time",
    difficulty: "intermediate",
    duration: "15-20 minutes",
    category: "Cell Biology",
    steps: [
      {
        id: 1,
        title: "Prophase",
        description: "Chromatin condenses into chromosomes",
        action: "Observe the chromatin condensation process",
        feedback: "Notice how the nuclear membrane begins to break down",
        image: "https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&q=80&w=1000"
      },
      {
        id: 2,
        title: "Metaphase",
        description: "Chromosomes align at the metaphase plate",
        action: "Help align the chromosomes at the center",
        feedback: "Perfect alignment is crucial for proper separation",
        image: "https://images.unsplash.com/photo-1582719471384-894fbb16e074?auto=format&fit=crop&q=80&w=1000"
      },
      {
        id: 3,
        title: "Anaphase",
        description: "Sister chromatids separate and move to opposite poles",
        action: "Watch the separation process",
        feedback: "The separation must be equal for healthy daughter cells",
        image: "https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&q=80&w=1000"
      }
    ]
  },
  {
    id: 2,
    title: "DNA Replication",
    description: "Explore the molecular mechanisms of DNA synthesis",
    difficulty: "advanced",
    duration: "25-30 minutes",
    category: "Molecular Biology",
    steps: [
      {
        id: 1,
        title: "Initiation",
        description: "DNA helicase unwinds the double helix",
        action: "Activate DNA helicase to begin unwinding",
        feedback: "Watch for the formation of the replication fork",
        image: "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?auto=format&fit=crop&q=80&w=1000"
      },
      {
        id: 2,
        title: "Elongation",
        description: "DNA polymerase adds nucleotides to growing strands",
        action: "Guide DNA polymerase along the template strands",
        feedback: "Notice the different synthesis rates on leading and lagging strands",
        image: "https://images.unsplash.com/photo-1614935151651-0bea6508db6b?auto=format&fit=crop&q=80&w=1000"
      }
    ]
  }
];

export function SimulationDemo() {
  const [currentSimulation, setCurrentSimulation] = useState<Simulation>(simulations[0]);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [showControls, setShowControls] = useState(true);

  const currentStep = currentSimulation.steps[currentStepIndex];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev < currentSimulation.steps.length - 1) {
            return prev + 1;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, 5000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, currentSimulation.steps.length]);

  const handleNext = () => {
    if (currentStepIndex < currentSimulation.steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
    setIsPlaying(false);
    setFeedback('');
  };

  const handleSimulationChange = (simulation: Simulation) => {
    setCurrentSimulation(simulation);
    setCurrentStepIndex(0);
    setIsPlaying(false);
    setFeedback('');
  };

  const handleAction = () => {
    setFeedback(currentStep.feedback);
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
      {/* Simulation Header */}
      <div className="p-6 bg-purple-900 text-white">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold">{currentSimulation.title}</h2>
            <p className="text-purple-200 mt-1">{currentSimulation.description}</p>
          </div>
          <div className="flex items-center space-x-4">
            <span className="px-3 py-1 bg-purple-800 rounded-full text-sm">
              {currentSimulation.difficulty}
            </span>
            <span className="px-3 py-1 bg-purple-800 rounded-full text-sm">
              {currentSimulation.duration}
            </span>
          </div>
        </div>
      </div>

      {/* Simulation Viewer */}
      <div className="relative aspect-video bg-gray-900">
        <img
          src={currentStep.image}
          alt={currentStep.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
          <h3 className="text-white text-xl font-semibold">{currentStep.title}</h3>
          <p className="text-white/90">{currentStep.description}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="p-6 border-t border-gray-200">
        <div className="flex justify-between items-center mb-4">
          <div className="flex space-x-4">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-2 rounded-lg hover:bg-purple-50 transition-colors"
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 text-purple-600" />
              ) : (
                <Play className="w-6 h-6 text-purple-600" />
              )}
            </button>
            <button
              onClick={handleReset}
              className="p-2 rounded-lg hover:bg-purple-50 transition-colors"
            >
              <RotateCcw className="w-6 h-6 text-purple-600" />
            </button>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={handlePrevious}
              disabled={currentStepIndex === 0}
              className="p-2 rounded-lg hover:bg-purple-50 transition-colors disabled:opacity-50"
            >
              <ChevronLeft className="w-6 h-6 text-purple-600" />
            </button>
            <button
              onClick={handleNext}
              disabled={currentStepIndex === currentSimulation.steps.length - 1}
              className="p-2 rounded-lg hover:bg-purple-50 transition-colors disabled:opacity-50"
            >
              <ChevronRight className="w-6 h-6 text-purple-600" />
            </button>
          </div>
        </div>

        {/* Action and Feedback */}
        <div className="space-y-4">
          <button
            onClick={handleAction}
            className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2"
          >
            <span>{currentStep.action}</span>
            <Beaker className="w-4 h-4" />
          </button>
          {feedback && (
            <div className="p-4 bg-purple-50 rounded-lg">
              <p className="text-purple-900">{feedback}</p>
            </div>
          )}
        </div>
      </div>

      {/* Simulation Selector */}
      <div className="p-6 bg-gray-50 border-t border-gray-200">
        <h3 className="text-lg font-semibold mb-4">Available Simulations</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {simulations.map(simulation => (
            <button
              key={simulation.id}
              onClick={() => handleSimulationChange(simulation)}
              className={`p-4 rounded-lg border-2 transition-colors ${
                currentSimulation.id === simulation.id
                  ? 'border-purple-600 bg-purple-50'
                  : 'border-gray-200 hover:border-purple-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-semibold">{simulation.title}</h4>
                  <p className="text-sm text-gray-600">{simulation.category}</p>
                </div>
                {simulation.category === 'Cell Biology' ? (
                  <Microscope className="w-5 h-5 text-purple-600" />
                ) : (
                  <Flask className="w-5 h-5 text-purple-600" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}