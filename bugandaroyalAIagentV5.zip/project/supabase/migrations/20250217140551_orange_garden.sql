/*
  # Add Communications System Tables

  1. New Tables
    - `message_templates`
      - Templates for emails and SMS messages
      - Supports variables for personalization
    - `scheduled_messages`
      - Scheduled bulk communications
      - Tracks status and delivery
    - `message_logs`
      - Records of sent messages
      - Tracks delivery status and engagement

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Message Templates
CREATE TABLE IF NOT EXISTS message_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  name text NOT NULL,
  subject text,
  content text NOT NULL,
  type text NOT NULL CHECK (type IN ('email', 'sms')),
  variables jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE message_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own templates"
  ON message_templates
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Scheduled Messages
CREATE TABLE IF NOT EXISTS scheduled_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  template_id uuid REFERENCES message_templates(id),
  recipients jsonb NOT NULL,
  scheduled_for timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE scheduled_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their scheduled messages"
  ON scheduled_messages
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Message Logs
CREATE TABLE IF NOT EXISTS message_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  scheduled_message_id uuid REFERENCES scheduled_messages(id),
  recipient text NOT NULL,
  type text NOT NULL CHECK (type IN ('email', 'sms')),
  status text NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'failed')),
  error_message text,
  sent_at timestamptz DEFAULT now()
);

ALTER TABLE message_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their message logs"
  ON message_logs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);